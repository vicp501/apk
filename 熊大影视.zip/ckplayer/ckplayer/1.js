showPlayer('https://www1.yuboyun.com/hls/2018/05/10/FsPqIm9o/playlist.m3u8','videoWrap')
function showPlayer(src, id){
     //player
   var flashvars={
        f : 'https://www1.yuboyun.com/hls/2018/05/10/FsPqIm9o/playlist.m3u8',
        a : src,
        c : 0,
        s:4,
        lv:0//ע�⣬�����ֱ����������lv:1
    };
    var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
    var video=[src];
    CKobject.embed('C:\Users\vissc\Downloads\ckplayer\ckplayer\ckplayer.swf',id ,'ck-video','100%','100%',false, flashvars ,video, params);
 
}